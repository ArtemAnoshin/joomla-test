DROP TABLE IF EXISTS `#__cleantalk_sfw`;
DROP TABLE IF EXISTS `#__cleantalk_sfw_logs`;
DROP TABLE IF EXISTS `#__cleantalk_sessions`;